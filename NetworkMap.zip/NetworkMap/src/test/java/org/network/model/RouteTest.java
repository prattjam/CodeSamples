package org.network.model;

import java.io.FileReader;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import org.network.BestRoute;

import junit.framework.TestCase;

public class RouteTest extends TestCase
{
	private static final String XML_MAP1_FILE = "src/test/resources/network-map1.xml";
	private static final String XML_MAP2_FILE = "src/test/resources/network-map2.xml";
	private static final String XML_MAP3_FILE = "src/test/resources/network-map3.xml";
	private static final String XML_MAP4_FILE = "src/test/resources/network-map4.xml";
	private static Logger log = Logger.getLogger(BestRoute.class.getName());

	@Test
	public void test1() throws Exception
	{
		// Test Routing capability with Map 1
		String source = "A";
		String destination = "B";
		NetworkMap map = new NetworkMap(new FileReader(XML_MAP1_FILE));
		BestRoute router = new BestRoute();
		Route myRoute = null;
		log.info("The World Map1:");
		map.getLinks().forEach(link -> log.info(link));

		router.loadMap(map);
		myRoute = router.createRoute(source, destination);

		// check the result of the test
		Assert.assertTrue(myRoute.getLinks().size() == 2);
		// verify route is A to D to B
		Assert.assertEquals(myRoute.getLinks().get(0).getNode1(), "A");
		Assert.assertEquals(myRoute.getLinks().get(0).getNode2(), "D");
		Assert.assertEquals(myRoute.getLinks().get(1).getNode1(), "D");
		Assert.assertEquals(myRoute.getLinks().get(1).getNode2(), "B");

		log.info("The Final Route:\n" + myRoute + "\n");
		// Completed Test of Map 1
	}

	@Test
	public void test2() throws Exception
	{
		// Create Map 2 and make a route from point A to E
		BestRoute router = new BestRoute();
		String source = "A";
		String destination = "E";
		NetworkMap map = new NetworkMap(new FileReader(XML_MAP2_FILE));
		router.loadMap(map);

		log.info("The World Map2:");
		map.getLinks().forEach(link -> log.info(link));

		Route route2 = router.createRoute(source, destination);
		// check the result of the test
		Assert.assertTrue(route2.getLinks().size() == 3);
		// verify route is A to C to F to E
		Assert.assertEquals(route2.getLinks().get(0).getNode1(), "A");
		Assert.assertEquals(route2.getLinks().get(0).getNode2(), "C");
		Assert.assertEquals(route2.getLinks().get(1).getNode1(), "C");
		Assert.assertEquals(route2.getLinks().get(1).getNode2(), "F");
		Assert.assertEquals(route2.getLinks().get(2).getNode1(), "F");
		Assert.assertEquals(route2.getLinks().get(2).getNode2(), "E");
		log.info("\nThe Final Route:\n" + route2 + "\n");
		// Completed Test of Map 2
	}

	@Test
	public void test3() throws Exception
	{

		// Use Map 2 and from xml file and modify the map and re-solve for best 
		//	route by adding a link and removing another
		BestRoute router = new BestRoute();
		String source = "A";
		String destination = "E";
		NetworkMap map = new NetworkMap(new FileReader(XML_MAP2_FILE));
		router.loadMap(map);
		
		// Test manipulate (add/remove edges and vertices
		log.info("\n\nModify the Network Map:");
		log.info("\n\tAdd Link(C, E, 10)");
		map.addLink(new Link("C", "E", 10, "link10"));
		
		log.info("\n\tRemove Link(E, D, 6)");
		map.removeLink(new Link("D", "E", 10, "link8"));
		
		router.loadMap(map);
		
		Route newRoute = router.createRoute(source, destination);
		// check the result of the test
		Assert.assertTrue(newRoute.getLinks().size() == 2);
		// verify route is A to C to E
		Assert.assertEquals(newRoute.getLinks().get(0).getNode1(), "A");
		Assert.assertEquals(newRoute.getLinks().get(0).getNode2(), "C");
		Assert.assertEquals(newRoute.getLinks().get(1).getNode1(), "C");
		Assert.assertEquals(newRoute.getLinks().get(1).getNode2(), "E");
		
		log.info("\nThe New Solution Route:\n" + newRoute);
	}

	@Test
	public void test4() throws Exception
	{
		// Create Asymmetric Map 3 and make a route from point A to E
		//Note: there are 2 Links between nodes A and C, one for each direction
		BestRoute router = new BestRoute();
		String source = "A";
		String destination = "E";
		NetworkMap map = new NetworkMap(new FileReader(XML_MAP3_FILE));
		router.loadMap(map);

		log.info("\n\nThe World Map3(Asymmetric):");
		map.getLinks().forEach(link -> log.info(link.toString()));

		Route route3 = router.createRoute(source, destination);		
		// check the result of the test
		Assert.assertTrue(route3.getLinks().size() == 3);
		// verify route is A to C to F to E
		Assert.assertEquals(route3.getLinks().get(0).getNode1(), "A");
		Assert.assertEquals(route3.getLinks().get(0).getNode2(), "C");
		Assert.assertEquals(route3.getLinks().get(1).getNode1(), "C");
		Assert.assertEquals(route3.getLinks().get(1).getNode2(), "F");
		Assert.assertEquals(route3.getLinks().get(2).getNode1(), "F");
		Assert.assertEquals(route3.getLinks().get(2).getNode2(), "E");
		
		log.info("\nThe Final Route:\n" + route3 + "\n");
		// Completed Test of Map 3
	}
	

	@Test
	public void test5() throws Exception
	{
		// Create Asymmetric Map 4 and make a route from point A to I
		BestRoute router = new BestRoute();
		String source = "A";
		String destination = "I";
		NetworkMap map = new NetworkMap(new FileReader(XML_MAP4_FILE));
		router.loadMap(map);

		log.info("\nThe World Map4(Asymmetric):");
		map.getLinks().forEach(link -> log.info(link.toString()));

		Route route4 = router.createRoute(source, destination);		
		// check the result of the test
		Assert.assertTrue(route4.getLinks().size() == 3);
		// verify route is A to C to F to E
		Assert.assertEquals(route4.getLinks().get(0).getNode1(), "A");
		Assert.assertEquals(route4.getLinks().get(0).getNode2(), "K");
		Assert.assertEquals(route4.getLinks().get(1).getNode1(), "K");
		Assert.assertEquals(route4.getLinks().get(1).getNode2(), "G");
		Assert.assertEquals(route4.getLinks().get(2).getNode1(), "G");
		Assert.assertEquals(route4.getLinks().get(2).getNode2(), "I");

		log.info("\nThe Final Route:\n" + route4 + "\n");
		// Completed Test of Map 4	
	}	
	
}
