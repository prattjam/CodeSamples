package org.network.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A route through a map of linked nodes from Source to Destination node
 */

/**
 * @author Jim Pratt
 *
 */
public class Route {

	private String source;
	private String destination;
	private Integer cost=0;
	private Integer numLinks=0;
	private List<String> visitedNodes = new ArrayList<>();
	private List<Link> links = new ArrayList<>();
	// map of shortest distance found for each node
	private Map<String, Integer> nodeDist = new HashMap<>();
	
	
	/**
	 * Route Constructor
	 * @param source
	 * @param destination
	 */
	public Route(String source, String destination) {
		super();
		this.source = source;
		this.destination = destination;
	}

	/**
	 * represent Route as String with all links
	 */
	public String toString()
	{
		String str = "";
		
		str = "Route [Source=" + source + " to Destination=" + destination + ", Total Cost=" + this.cost + 
				", Number of Links=" + this.numLinks + "]";
		for(Link link : links)
		{
			str += "\n\t" + link.toString();
		}
		
		return str;
	}
	
	/**
	 * Add a link from the map to this route
	 * @param newLink
	 * @param newDest
	 */
	public void addLink(Link newLink, String newDest)
	{
		this.links.add(newLink);
		this.visitedNodes.add(newDest);
		this.cost += newLink.getCost();
		this.numLinks += 1;
	}
	
	
	/**
	 * Find a Link to the input node
	 * 
	 * @param node
	 * @return
	 */
	public Link getBestLinkToNode(String node)
	{
		Link nodeLink = null;
		String nextNode = null; 
		Integer minDistance = Integer.MAX_VALUE;
		Integer linkCost = new Integer(0);
		Map<String, Integer> nodeDist = this.getNodeDist();
		
		for (Link link : this.getLinks())
		{
			if (link.hasNode(node))
			{
				nextNode = link.getOtherNode(node);
				linkCost = nodeDist.get(nextNode) + link.getCost();
				if (linkCost < minDistance)
				{
					nodeLink = link;
					minDistance = linkCost;
				}			
			}
		}
		
		return nodeLink;
	}
	
	
	/**
	 * @return the links
	 */
	public List<Link> getLinks() {
		return links;
	}
	/**
	 * @param links the links to set
	 */
	public void setLinks(List<Link> links) {
		this.links = links;
	}

	/**
	 * @return the nodeDist
	 */
	public Map<String, Integer> getNodeDist() {
		return nodeDist;
	}

	/**
	 * @param nodeDist the nodeDist to set
	 */
	public void setNodeDist(Map<String, Integer> nodeDist) {
		this.nodeDist = nodeDist;
	}

	
	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}
	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}
	/**
	 * @return the destination
	 */
	public String getDestination() {
		return destination;
	}
	/**
	 * @param destination the destination to set
	 */
	public void setDestination(String destination) {
		this.destination = destination;
	}
	/**
	 * @return the cost
	 */
	public Integer getCost() {
		return cost;
	}
	/**
	 * @param cost the cost to set
	 */
	public void setCost(Integer cost) {
		this.cost = cost;
	}
	/**
	 * @return the numLinks
	 */
	public Integer getNumLinks() {
		return numLinks;
	}
	/**
	 * @param numLinks the numLinks to set
	 */
	public void setNumLinks(Integer numLinks) {
		this.numLinks = numLinks;
	}
	/**
	 * @return the visitedNodes
	 */
	public List<String> getVisitedNodes() {
		return visitedNodes;
	}
	/**
	 * @param visitedNodes the visitedNodes to set
	 */
	public void setVisitedNodes(List<String> visitedNodes) {
		this.visitedNodes = visitedNodes;
	}
	
	
}