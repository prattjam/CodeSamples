package org.network.model;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "link")
@XmlAccessorType(XmlAccessType.FIELD)
// If you want you can define the order in which the fields are written
// Optional
@XmlType(propOrder =
{ "id", "node1", "node2", "cost", "asymmetric" })

public class Link
{
	private String node1 = null;
	private String node2 = null;
	private Integer cost;
	private String id = null;
	private boolean asymmetric = false;

	/** 
	 * Constructor with most link object properties included
	 * 
	 * @param node1
	 * @param node2
	 * @param cost
	 * @param id
	 */
	public Link(String node1, String node2, Integer cost, String id)
	{
		super();
		this.node1 = node1;
		this.node2 = node2;
		this.cost = cost;
		this.id = id;
	}

	/**
	 * default no argument constructor
	 */
	public Link()
	{
		super();
	}

	/**
	 * @param String
	 *            node
	 * @return boolean : does this Link contain the input node
	 */
	public boolean hasNode(String node)
	{
		boolean result = false;
		if (node1.equals(node) || node2.equals(node))
		{
			result = true;
		}

		return result;
	}

	/**
	 * @param String
	 *            node
	 * @return String : return the node on the other side of the link from the
	 *         input node
	 */
	public String getOtherNode(String node)
	{
		String otherNode = null;
		if (node1.equals(node))
		{
			otherNode = node2;
		} else if (node2.equals(node))
		{
			otherNode = node1;
		}

		return otherNode;
	}

	/**
	 *  override toString() so can print link properties nicely when testing
	 */
	@Override
	public String toString()
	{
		return "Link [node1=" + node1 + " to node2=" + node2 + ", cost=" + cost + ", id=" + id + "]";
	}

	/**
	 * override equals() to make sure this object can be found in a container/List
	 */
	@Override
	public boolean equals(Object obj)
	{
		boolean result = false;
		Link other = null;

		if (this == obj)
		{
			result = true;
		} else if ((obj != null) && (obj instanceof Link))
		{
			other = (Link) obj;

			// For Asymmetric links soure must equal source node and destination
			// equal destination
			if (this.asymmetric && this.node1.equals(other.node1) && this.node2.equals(other.node2))
			{
				result = true;
			}
			// Not Asymmetric consider a link from node A to node B equivalent
			// to Link of B to A
			else if (!this.asymmetric && ((this.node1.equals(other.node1) && this.node2.equals(other.node2))
					|| (this.node2.equals(other.node1) && this.node1.equals(other.node2))))
			{
				result = true;
			}
		}

		return result;
	}

	/**
	 * override hashCode() to make sure this object can be found in a container/List
	 */
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((node1 == null) ? 0 : node1.hashCode());
		result = prime * result + ((node2 == null) ? 0 : node2.hashCode());
		return result;
	}

	/**
	 * @return the node1
	 */
	public String getNode1()
	{
		return node1;
	}

	/**
	 * @param node1
	 *            the node1 to set
	 */
	public void setNode1(String node1)
	{
		this.node1 = node1;
	}

	/**
	 * @return the node2
	 */
	public String getNode2()
	{
		return node2;
	}

	/**
	 * @param node2
	 *            the node2 to set
	 */
	public void setNode2(String node2)
	{
		this.node2 = node2;
	}

	/**
	 * @return the cost
	 */
	public Integer getCost()
	{
		return cost;
	}

	/**
	 * @param cost
	 *            the cost to set
	 */
	public void setCost(Integer cost)
	{
		this.cost = cost;
	}

	/**
	 * @return the id
	 */
	public String getId()
	{
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id)
	{
		this.id = id;
	}

	/**
	 * @return the asymmetric
	 */
	public boolean getAsymmetric()
	{
		return asymmetric;
	}

	/**
	 * @param asymmetric
	 *            the asymmetric to set
	 */
	public void setAsymmetric(boolean asymmetric)
	{
		this.asymmetric = asymmetric;
	}

}
