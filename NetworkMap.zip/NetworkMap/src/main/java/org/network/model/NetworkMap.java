package org.network.model;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.log4j.Logger;
import org.network.BestRoute;

//This statement means that class "NetworkMap.java" is the root-element of our xml file
@XmlRootElement(name = "networkMap", namespace = "org.network.model")
// set order in which fields are written
@XmlType(propOrder =
{ "name", "asymmetric", "links", "nodeSet" })
public class NetworkMap
{

	// The problem map of Links/edges to solve routes for
	private List<Link> nodeMap = new ArrayList<>();
	private Set<String> nodeSet = new HashSet<>(); // list of all nodes/vertices
													// in the map
	private String name;
	private boolean asymmetric = false;
	private static Logger log = Logger.getLogger(NetworkMap.class.getName());

	/**
	 * @return the nodeMap
	 */
	@XmlElementWrapper(name = "linkList")
	// XmlElement sets the name of the entities
	@XmlElement(name = "link")
	public List<Link> getLinks()
	{
		return this.nodeMap;
	}

	/**
	 * set the nodeMap to use for this NetworkMap object
	 * 
	 * @param nodeMap
	 */
	public void setLinks(List<Link> nodeMap)
	{
		this.nodeMap = nodeMap;
	}

	/**
	 * Constructor to load this NetworkMap from the XML file passed as a
	 * FileReader
	 * 
	 * @param reader
	 * @throws Exception
	 */
	public NetworkMap(FileReader reader) throws Exception
	{
		JAXBContext context = JAXBContext.newInstance(NetworkMap.class);
		Unmarshaller um = context.createUnmarshaller();
		NetworkMap map = (NetworkMap) um.unmarshal(reader);
		this.nodeMap = map.getLinks();
		this.nodeSet = map.getNodeSet();
		this.name = map.getName();
		this.asymmetric = map.getAsymmetric();
	}

	/**
	 * method used to initially create an XML file to hold NetworkMap
	 * 
	 * @param file
	 * @throws Exception
	 */
	public void saveMapToXML(File file) throws Exception
	{
		try
		{
			// create JAXB context and instantiate marshaller
			JAXBContext context = JAXBContext.newInstance(NetworkMap.class);
			Marshaller xmlWriter = context.createMarshaller();

			xmlWriter.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

			// Write to System.out
			xmlWriter.marshal(this, System.out);

			// Write to File
			xmlWriter.marshal(this, file);
		} 
		catch (JAXBException e)
		{
			log.error("Error: saving Map to XML file!");
			e.printStackTrace();
			throw new Exception(e);
		}
	}

	/**
	 * Add a new Edge/Link to the Network Map
	 * 
	 * @param newLink
	 */
	public void addLink(Link newLink)
	{
		if (nodeSet.contains(newLink.getNode1()))
		{
			nodeSet.add(newLink.getNode1());
		}
		
		if (nodeSet.contains(newLink.getNode2()))
		{
			nodeSet.add(newLink.getNode2());
		}

		if (!nodeMap.contains(newLink))
		{
			nodeMap.add(newLink);
		}
	}

	/**
	 * Remove an Edge/Link in the Network Map
	 * 
	 * @param badLink
	 */
	public void removeLink(Link badLink)
	{
		if (nodeMap.remove(badLink))
		{
			String source = badLink.getNode1();
			String destination = badLink.getNode2();
			boolean hasSource = false;
			boolean hasDestination = false;

			// check if there is a link in the map with source and destination
			// nodes in it
			for (Link link : nodeMap)
			{
				if (link.hasNode(source))
					hasSource = true;
				if (link.hasNode(destination))
					hasDestination = true;
			}

			// remove source/dest from nodeSet if there no longer exists a link
			// in the map to it
			if (!hasSource)
				nodeSet.remove(source);
			if (!hasDestination)
				nodeSet.remove(destination);
		}
	}

	/**
	 * @return the name
	 */
	@XmlElement(name = "mapName")
	public String getName()
	{
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * @return the nodeSet
	 */
	// XmlElement sets the name of the entities
	@XmlElementWrapper(name = "nodeList")
	@XmlElement(name = "node")
	public Set<String> getNodeSet()
	{
		return nodeSet;
	}

	/**
	 * @param nodeSet
	 *            the nodeSet to set
	 */
	public void setNodeSet(Set<String> nodeSet)
	{
		this.nodeSet = nodeSet;
	}

	public NetworkMap()
	{
		super();
	}

	/**
	 * @return the asymmetric
	 */
	public boolean getAsymmetric()
	{
		return asymmetric;
	}

	/**
	 * @param asymmetric
	 *            the asymmetric to set
	 */
	public void setAsymmetric(boolean asymmetric)
	{
		this.asymmetric = asymmetric;

		for (Link link : this.getLinks())
		{
			link.setAsymmetric(asymmetric);
		}
	}

}
