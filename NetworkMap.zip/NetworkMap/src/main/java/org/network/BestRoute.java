package org.network;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.network.model.Link;
import org.network.model.NetworkMap;
import org.network.model.Route;

/**
 * @author Jim Pratt
 *
 */
public class BestRoute
{
	// The problem map to solve routes for
	private List<Link> nodeMap = new ArrayList<>();
	private Set<String> nodeSet = new HashSet<>();
	private boolean asymmetric = false;
	/* Get actual class name to be printed on */
	private static Logger log = Logger.getLogger(BestRoute.class.getName());

	/**
	 * Load input map as into nodeMap and nodeSet used by the BestRoute object
	 * 
	 * @param map
	 */
	public void loadMap(NetworkMap map)
	{
		this.nodeMap = map.getLinks();
		this.nodeSet = map.getNodeSet();
		if (map.getAsymmetric())
		{
			this.asymmetric = true;
			map.setAsymmetric(this.asymmetric);
		} else
		{
			this.asymmetric = false;
			map.setAsymmetric(this.asymmetric);
		}
	}

	/**
	 * Find a route from the source to the destination through Graph/Map
	 * using Dijkstra�s Algorithm
	 * 
	 * @param source
	 * @param destination
	 * @return
	 */
	public Route createRoute(String source, String destination)
	{
		Route myRoute = null;
		Map<String, Integer> nodeDist = null;

		myRoute = discoverRoutes(source, destination);
		log.debug("The Initial Route:\n" + myRoute);

		nodeDist = myRoute.getNodeDist();
		
		log.info("\nMap Node distances to source: " + source + ":");
		nodeDist.forEach((k, v) -> log.info("\tDistance[" + k + "] = " + v));
		
		myRoute = removeWrongTurns(myRoute, destination, source);

		return myRoute;
	}

	/**
	 * Find the shortest route from source to destination using the Dijkstra
	 * Algorithm
	 * 
	 * @param source
	 * @param destination
	 * @return
	 */
	private Route discoverRoutes(String source, String destination)
	{

		Set<String> unsettledNodes = new HashSet<>();
		Set<String> settledNodes = new HashSet<>();
		String evaluationNode = "";

		Route route = new Route(source, destination);
		Map<String, Integer> nodeDist = route.getNodeDist();

		// For each node set distance[node] = HIGH
		for (String nodeName : nodeSet)
		{
			nodeDist.put(nodeName, Integer.MAX_VALUE);
		}

		// Add sourceNode to UnSettledNodes
		unsettledNodes.add(source);
		// distance[sourceNode]= 0
		nodeDist.replace(source, 0);

		while (!unsettledNodes.isEmpty())
		{
			evaluationNode = getNodeWithLowestDistance(unsettledNodes, nodeDist);
			unsettledNodes.remove(evaluationNode);
			settledNodes.add(evaluationNode);

			// evaluatedNeighbors(evaluationNode)
			evaluateNeighbors(evaluationNode, settledNodes, unsettledNodes, route);
		}

		return route;
	}

	
	/**
	 * Evaluate all the neighboring nodes linked to the evaluation node and
	 * 	and update calculated distance for each node found to the source node
	 * 	as long as the neighbor node found is not in the Settled Node set.
	 * 	If a shorter distance is found to the neighbor node than previously 
	 *  calculated then the neighbor node is added to the unsettled node set
	 *  and the link is added to the route solution object.
	 *   
	 * @param evaluationNode
	 * @param settledNodes
	 * @param unsettledNodes
	 * @param route
	 */
	private void evaluateNeighbors(String evaluationNode, Set<String> settledNodes, Set<String> unsettledNodes,
			Route route)
	{
		String destinationNode = null;
		Integer linkCost = null;
		Integer newDistance = null;
		Map<String, Integer> nodeDist = route.getNodeDist();
		List<Link> neighborLinks = getNeighborLinks(evaluationNode, this.nodeMap);

		for (Link evalLink : neighborLinks)
		{
			destinationNode = evalLink.getOtherNode(evaluationNode);

			if (!settledNodes.contains(destinationNode))
			{
				linkCost = evalLink.getCost();
				newDistance = nodeDist.get(evaluationNode) + linkCost;

				// if (distance[destinationNode] > newDistance )
				if (nodeDist.get(destinationNode) > newDistance)
				{
					nodeDist.put(destinationNode, newDistance);
					unsettledNodes.add(destinationNode);
					route.addLink(evalLink, destinationNode);
				}
			}
		}
	}

	
	/**
	 * get a list of all the links that will take you to a neighboring node of the 
	 * evaluation node.
	 * 
	 * @param evaluationNode
	 * @param nodeMap
	 * @return
	 */
	private List<Link> getNeighborLinks(String evaluationNode, List<Link> nodeMap)
	{
		List<Link> neighborLinks = new ArrayList<Link>();

		for (Link link : nodeMap)
		{
			if (this.asymmetric && link.getNode1().equals(evaluationNode))
			{
				neighborLinks.add(link);
			}
			if (!this.asymmetric && link.hasNode(evaluationNode))
			{
				neighborLinks.add(link);
			}
		}
		return neighborLinks;
	}

	/**
	 * find the node with the lowest distance in UnSettledNodes and return it
	 * 
	 * @param unsettledNodes
	 * @param distance
	 * @return minNode
	 */
	private String getNodeWithLowestDistance(Set<String> unsettledNodes, Map<String, Integer> distance)
	{
		String minNode = null;
		Integer minDistance = Integer.MAX_VALUE;

		for (String node : unsettledNodes)
		{
			if ((Integer) distance.get(node) < minDistance)
			{
				minDistance = (Integer) distance.get(node);
				minNode = node;
			}

		}
		return minNode;
	}

	/**
	 * walk back through the route and remove the links that were wrong turns
	 * 
	 * @param route
	 * @param destination
	 * @param source
	 * @return
	 */
	private Route removeWrongTurns(Route route, String destination, String source)
	{
		List<Link> bestLinks = new ArrayList<>();
		Link link = null;
		Integer cost = new Integer(0);
		int i = 0;
		int size = route.getLinks().size();
		String newNode = destination;

		for (i = 0; !source.equals(newNode) && (i <= size); i++)
		{
			link = route.getBestLinkToNode(newNode);
			bestLinks.add(link);
			cost = cost + link.getCost();
			newNode = link.getOtherNode(newNode);
			route.getLinks().remove(link);
		}

		Collections.reverse(bestLinks);
		route.setLinks(bestLinks);
		route.setCost(cost);
		route.setNumLinks(i);
		if (i >= size)
		{
			log.error("Error: No good routes found!");
		}

		return route;
	}

	/**
	 * 
	 */
	public BestRoute()
	{
		super();
	}

	public BestRoute(NetworkMap map)
	{
		this();
		this.loadMap(map);
	}

}